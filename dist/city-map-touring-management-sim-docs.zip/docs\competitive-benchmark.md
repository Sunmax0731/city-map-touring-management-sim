# 競合ベンチマーク

比較観点は初回起動、代表データ、手動テスト証跡、Game としての実行環境一致です。本repoは static Web management sim prototype / GitHub Pages を実行確認できることを優先します。
